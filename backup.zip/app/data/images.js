export const imagesData = [
    {
      small: "/mobile-images/Snood-Hotel-Small.webp",
      large: "/desktopImages/Snood-Big-Hotel.webp",
    },
    {
      small: "/mobile-images/Snood-Ajyad-Hotel_4_thumbnail.jpg",
      large: "/desktopImages/Snood-Ajyad-Hotel_4.jpg",
    },
    {
      small: "/mobile-images/Snood-Ajyad-Hotel_2_thumbnail.jpg",
      large: "/desktopImages/Snood-Ajyad-Hotel_2.jpg",
    },
    {
      small: "/mobile-images/Snood-Ajyad-Hotel_3_thumbnail.jpg",
      large: "/desktopImages/Snood-Ajyad-Hotel_3.jpg",
    },
    {
      small: "/mobile-images/Snood-Ajyad-Hotel_location.jpg",
      large: "/desktopImages/Snood-Ajyad-Hotel_Location_full.jpg",
    },
  ];